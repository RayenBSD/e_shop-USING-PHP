<?php 

    include("../dbconnect.php");

    $product_id = $_GET['product_id'];
    $user_id = $_GET['user_id'];

    if($conn->query("DELETE FROM carts WHERE product_id=$product_id AND user_id=$user_id") !== TRUE) {
        die("Erro when deleting");
    }
    
    echo "<script>alert('Item deleted')</script>";
    header("location: cart.php?user_id=$user_id");

    $conn->close();
?>