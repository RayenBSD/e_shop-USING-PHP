<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" href="cart.css">

        <title>By Products</title>
    </head>
    <body>
        
        <div class="items">
            <?php 
                
                include("../dbconnect.php");

                $user_id = $_GET['user_id'];

                $getData = $conn->query("SELECT * FROM carts
                                            RIGHT JOIN products
                                            ON carts.product_id = products.ID
                                            WHERE carts.user_id = $user_id");
                
                if ($getData->num_rows > 0) {
                    while ($row = $getData->fetch_assoc()) {
                        echo '<div class="item">
                                <img src="data:image/jpeg;base64,'.base64_encode($row['image']).'" alt="Product image" width="100px" height="100px">

                                <p>'.$row['name'].'</p>
                                <p>'.$row['price'].'$</p>

                                <a href="delete.php?product_id='.$row['product_id'].'&user_id='.$row['user_id'].'">Delete</a>
                            </div>
                        '; 
                    }
                }
                else {
                    $conn->close();
                    echo "<center><h1>Empty!!!</h1></center>";
                }
            ?>

            
        </div>
    </body>
</html>