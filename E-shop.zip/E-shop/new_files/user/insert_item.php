<?php

    include("../dbconnect.php");
    //$_SERVER[HTTP_REFERER]

    if (isset($_GET['id'])) {
        $user_id = $_GET['user_id'];
        $product_id = $_GET['id'];

        $conn->query("INSERT INTO carts(user_id, product_id) VALUES ($user_id, $product_id)");

        $conn->close();
        $back = $_SERVER['HTTP_REFERER'];
        header("Location: $back");
    }
    else {
        $conn->close();
        header("location: main.php");
    }

?>