<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" href="sign.css">

        <title>Sign In</title>
    </head>
    <body>
        <form action="reg.php" method="POST">
            <div class="email">
                <label for="fname">First name</label><br>
                <input name="fname" id="fname" type="text" placeholder="Enter your first name" required>
            </div>
            <div class="email">
                <label for="lname">Last name</label><br>
                <input name="lname" id="lname" type="text" placeholder="Enter your last anme" required>
            </div>
            <div class="email">
                <label for="email">Email</label><br>
                <input name="email" id="email" type="email" placeholder="Enter your email" required>
            </div>
            <div class="passwd">
                <label for="passwd">Password</label><br>
                <input name="passwd" id="passwd" type="password" placeholder="Enter your password" required>
            </div>
            <div class="submit">
                <input type="submit" value="Sign In" name="signup">
            </div>
            <div>
                <a href="signin.php">Sign in</a>
            </div>
        </form>
    </body>
</html>