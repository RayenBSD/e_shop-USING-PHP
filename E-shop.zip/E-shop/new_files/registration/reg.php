<?php 

    include("../dbconnect.php");
    /*
    if ($_ENV['HAS_LOGIN'] && $_ENV['IS_LOGGER_ADMIN']) {
        $conn->close();
        if ($_ENV['IS_LOGGER_ADMIN']) {
            header("location: ../admin/main.php");
        }
        else {
            header("location: ../user/main.php");
        }
    }
    */
    //else {
        

        if (isset($_POST['signin'])) {
            if (empty($_POST['email']) && empty($_POST['passwd'])) {

                $conn->close();
                header("location: signin.php");
            }

            $res = "SELECT * FROM users WHERE email='".$_POST['email']."'";
            $res = $conn->query($res);
            
            if ($res->num_rows > 0) {
                $res = $res->fetch_assoc();

                $check_password = $_POST['passwd'];
                $check_password = password_verify($check_password, $res['password']);

                if ($check_password) {
                    if ($res['email'] == "admin@gmail.com") {
                        $conn->close();
                        header("location: ../admin/main.php");
                    }
                    else {
                        $conn->close();
                        header("location: ../user/main.php?user_id=".$res['ID']);
                    }
                }
                else {
                    echo "<script>Check your data</script>";
                    $conn->close();
                    header("location: signin.php");
                }
            }
            else {
                echo "<script>Check your data</script>";
                $conn->close();
                header("location: signin.php");
            }
            

        }
        elseif (isset($_POST['signup'])) {

            if (empty($_POST['email']) && empty($_POST['passwd']) && empty($_POST['fname']) && empty($_POST['lname'])) {
                $conn->close();
                header("location: signup.php");
            }

            $password = $_POST['passwd'];
            $password = password_hash($password, PASSWORD_DEFAULT);

            $fname = addslashes(strip_tags($_POST['fname']));
            $lname = addslashes(strip_tags($_POST['lname']));
            $email = addslashes(strip_tags($_POST['email']));

            $res = "INSERT INTO users(first_name, last_name, email, password) VALUES ('$fname', '$lname', '$email', '$password')";
            
            $conn->query($res);

            $conn->close();
            header("location: signin.php");
        }
        else {
            $conn->close();
            header("location: signup.php");
        }
    //}

?>