<?php

    require_once realpath(__DIR__ . "/vendor/autoload.php");
    use Dotenv\Dotenv;

    $dotenv = Dotenv::createImmutable(__DIR__);
    $dotenv->load();

    //create databse with name e_shop

    $conn = new mysqli($_ENV["LOCALHOST"], $_ENV['USER_NAME'], $_ENV['PASSWORD'], $_ENV['DB']);

    if ($conn->connect_error) {
        die("Failed to connect: ". $conn->connect_error);
    }

    /*
    $conn->query("CREATE TABLE IF NOT EXISTS users (
        ID INT NOT NULL UNIQUE AUTO_INCREMENT,
        first_name varchar(100) NOT NULL,
        last_name varchar(100) NOT NULL,
        email varchar(100) NOT NULL,
        password varchar(255) NOT NULL,
        
        PRIMARY KEY (ID)
    )");

    $conn->query("CREATE TABLE IF NOT EXISTS products (
        ID INT NOT NULL UNIQUE AUTO_INCREMENT,
        name varchar(100) NOT NULL,
        price INT NOT NULL,
        image longblob NOT NULL,
        
        PRIMARY KEY (ID)
    )");

    $conn->query("CREATE TABLE IF NOT EXISTS carts (
        ID INT NOT NULL UNIQUE AUTO_INCREMENT,
        user_id INT NOT NULL,
        product_id INT NOT NULL,

        PRIMARY KEY (ID),

        FOREIGN KEY (user_id) REFERENCES users(ID),
    	FOREIGN KEY (product_id) REFERENCES products(ID)
    )");
    */
?>