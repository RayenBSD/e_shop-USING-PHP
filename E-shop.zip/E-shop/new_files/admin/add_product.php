<?php

    include("../dbconnect.php");

    //if (!($_ENV['HAS_LOGIN'] && $_ENV['IS_LIGGER_ADMIN'])) {

        if(isset($_POST['add']) && !empty($_POST['name']) && !empty($_POST['price']) && !empty($_FILES['image']['tmp_name'])) {


            $name = addslashes(strip_tags($_POST['name']));
            $price = addslashes(strip_tags($_POST['price']));
            $image = addslashes(file_get_contents($_FILES['image']['tmp_name']));

            $insert = "INSERT INTO products (name, price, image) VALUES ('$name', '$price', '$image')";

            if ($conn->query($insert) === TRUE) {
                echo "<script>alert('Data inserted')</script>";
            }
            else {
                echo "<script>alert('Failed to insert data')</script>";
            }
            
            $conn->close();
            header("location: main.php");
        }
        else {
            $conn->close();
            header("location: ../errors/admin/enter_all_data.html");
        }
    //}
    //else {
        //$conn->close();
        //header("location: ../errors/admin/admin.html");
    //}
?>