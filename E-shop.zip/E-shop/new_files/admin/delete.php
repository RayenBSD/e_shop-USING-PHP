<?php 

    include("../dbconnect.php");

    $param = $_GET['id'];

    if($conn->query("DELETE FROM products WHERE id=".$param) !== TRUE) {
        $conn->close();
        die("Erro when deleting");
    }
    
    echo "<script>alert('Item deleted')</script>";
    header("location: get.php");

    $conn->close();
?>