<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <link rel="stylesheet" href="main.css">
        
        <title>Edit Product</title>
    </head>
    <body>
        
        <?php
            include("../dbconnect.php");

            $param = $_GET['id'];
            $result = $conn->query("SELECT * FROM products WHERE id=".$param);
            
            if (!$result) {
                die("Error when fetching data (edit.php)");
            }

            $result = $result->fetch_assoc();

            echo '<form action="update.php?id='.$param.'" method="POST"  enctype="multipart/form-data">
                    <div class="logo">
                        <img src="data:image/jpeg;base64,'.base64_encode($result['image']).'" alt="Edit logo" width="250px" height=250px>
                    </div>
                    <div>
                        <label for="name">Name:</label><br>
                        <input type="text" name="name" id="name" placeholder="Enter product\'s name" value="'.$result['name'].'">
                    </div>
                    <div>
                        <label for="price">Price:</label><br>
                        <input type="number" name="price" id="price" placeholder="Enter product\'s price" value="'.$result['price'].'" required>
                    </div>
                    <div>
                        <label for="image">Uplaod an image:</label>
                        <input type="file" id="file" name="image">
                    </div>
                    <div>
                        <input type="submit" value="edit" id="submit" name="edit">
                    </div>
                </form>
            ';
            $conn->close();
        ?>
        

        
        <form action="main.php" class="check-products">
            <input type="submit" value="Back Home">
        </form>

    </body>
</html>