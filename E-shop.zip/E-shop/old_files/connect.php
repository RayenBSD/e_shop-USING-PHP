<?php

    $hostName = "127.0.0.1";
    $db = "e_shop";
    $username = "root";
    $password = "";

    $conn = new mysqli($hostName, $username, $password, $db);

    if ($conn->connect_error) {
        die("Failed to connect: ". $conn->connect_error);
    }

?>