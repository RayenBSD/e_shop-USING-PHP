<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" href="get.css">

        <title>Products</title>
    </head>
    <body>

        <div class="main">
        
            <form action="main.php" class="back-to-home">
                <input type="submit" value="Back to home">
            </form>

            <div class="products">
                
                <?php
                    include("connect.php");

                    $result = $conn->query("SELECT * FROM $db ORDER BY id DESC");

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                           echo '<div class="container">
                                    <div class="img">
                                        <img src="data:image/jpeg;base64,'.base64_encode($row['image']).'" alt="Product image" width="175px" height="175px">
                                    </div>
                                    <div class="body">
                                        <h1>'.$row['name'].'</h1>
                                        <p>'.$row['price'].'$</p>
                                    </div>
                                    <div class="modify">
                                        <a href="edit.php?id='.$row['id'].'" id="edit">Edit</a>
                                        <a href="delete.php?id='.$row['id'].'" id="delete">Delete</a>
                                    </div>
                                </div>
                            '; 
                        }
                    }
                    else {

                    }

                    $conn->close();
                ?>
            </div>
        </div>
    </body>
</html>