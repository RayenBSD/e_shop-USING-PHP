<?php

    include("connect.php");

    $getItem = $conn->query("SELECT * FROM $db WHERE id=".$_GET['id']);
    $getItem = $getItem->fetch_assoc();


    if(empty($getItem['name'])) {
        header("location: 404.php");
        $conn->close();
    }   
    $name = $getItem['name'];
    $price = $getItem['price'];
    $image = "data:image/jpeg;base64,".base64_encode($getItem['image']);

    $conn->close();

    $image = addslashes(file_get_contents($image));

    $cartConn = new mysqli("localhost", "root", "", "e_shop");
    if ($cartConn->connect_error) {
        die("Failed to connect: ". $cartConn->connect_error);
    }

    $cartInsert = $cartConn->query("INSERT INTO cart(name, price, image) VALUES ('$name', '$price', '$image')");
    header("location: shopping.php");

    $cartConn->close();
?>