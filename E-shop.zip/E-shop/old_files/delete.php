<?php 

    include("connect.php");

    $param = $_GET['id'];

    if($conn->query("DELETE FROM e_shop WHERE id=".$param) !== TRUE) {
        die("Erro when deleting");
    }
    
    echo "<script>alert('Item deleted')</script>";
    header("location: get.php");

    $conn->close();
?>