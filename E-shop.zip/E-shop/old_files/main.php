<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" href="main.css">

        <!--<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>-->

        <title>E-Shop</title>
    </head>
    <body>

        <form action="post.php" method="POST" enctype="multipart/form-data">
            <div class="logo">
                <img src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fclipground.com%2Fimages%2Fretail-store-clip-art-2.png&f=1&nofb=1" alt="E-Shop logo" width="250px">
            </div>
            <div>
                <label for="name">Name:</label><br>
                <input type="text" name="name" id="name" placeholder="Enter product's name" required>
            </div>
            <div>
                <label for="price">Price:</label><br>
                <input type="number" name="price" id="price" placeholder="Enter product's price" required>
            </div>
            <div>
                <label for="image">Uplaod an image:</label>
                <input type="file" id="file" name="image" required>
            </div>
            <div>
                <input type="submit" value="Add" id="submit" name="add">
            </div>
        </form>
        
        <form action="get.php" class="check-products">
            <input type="submit" value="Check all products">
        </form>

    </body>
    <!--<script>
        $(function() {
            $("#submit").click(() => {
                if ($("#file").val() == '') {
                    alert("Add an image!!!");
                    return false;
                }
                else {
                    var type = $("#file").val().split('.').pop().toLowerCase();
                    if (jQuery.inArray(type, ["jpg", "jpeg", "png", "gif"]) == -1) {
                        alert("Invalid image type, only (jpg, jpeg, png, gif)");
                    }
                }
            });
        })
    </script>-->
</html>