<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" href="404.css">

        <title>Error!</title>
    </head>
    <body>
        <div>
            <h1>404 <span>|</span> Error!</h1>
            <a href="shopping.php">Back to products</a>
        </div>
    </body>
</html>