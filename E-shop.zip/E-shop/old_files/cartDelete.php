<?php 

    $cartConn = new mysqli("localhost", "root", "", "e_shop");
    if ($cartConn->connect_error) {
        die("Failed to connect: ". $cartConn->connect_error);
    }

    $cartConn->query("DELETE FROM cart WHERE id=".$_GET['id']);

    $cartConn->close();

    header("location: cart.php");
?>