<?php     
    if(isset($_POST['edit'])) {

        include("connect.php");
        //print(addslashes(file_get_contents($_FILES['image']['tmp_name'])));

        if (empty($_FILES['image']['tmp_name']) && !empty($_POST['name']) && !empty($_POST['price'])) {
            $res = "UPDATE e_shop set name='".$_POST['name']."', price='".$_POST['price']."' WHERE id=".$_GET['id'];

            if ($conn->query($res) === TRUE) {
                echo "<script>alert('Updated successfully')</script>"; 
            }
            else {
                echo "<script>alert('Failed to update')</script>"; 
            }
                   
        }
        else {
        
            $img = addslashes(file_get_contents($_FILES['image']['tmp_name']));

            $res = "UPDATE e_shop set name='".$_POST['name']."', price='".$_POST['price']."', image='$img' WHERE id=".$_GET['id'];

            if ($conn->query($res)) {
                echo "<script>alert('Updated successfully')</script>"; 
            }
            else {
                echo "<script>alert('Failed to update')</script>"; 
            }  
        }
        header("location: get.php");
        $conn->close();
    }
?>