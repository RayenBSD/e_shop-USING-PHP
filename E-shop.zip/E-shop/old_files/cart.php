<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" href="cart.css">

        <title>By Products</title>
    </head>
    <body>

        <div class="back-to-shopping">
            <a href="shopping.php">Back to shop</a>
        </div>
        
        <div class="items">
            <?php 
                
                $cartConn = new mysqli("localhost", "root", "", "e_shop");
                if ($cartConn->connect_error) {
                    die("Failed to connect: ". $cartConn->connect_error);
                }

                $getData = $cartConn->query("SELECT * FROM cart");
                
                if ($getData->num_rows > 0) {
                    while ($row = $getData->fetch_assoc()) {
                        echo '<div class="item">
                                <img src="data:image/jpeg;base64,'.base64_encode($row['image']).'" alt="Product image" width="100px" height="100px">

                                <p>'.$row['name'].'</p>
                                <p>'.$row['price'].'$</p>

                                <a href="cartDelete.php?id='.$row['id'].'">Delete</a>
                            </div>
                        '; 
                    }
                }
            ?>

             
        </div>
    </body>
</html>