<?php
    
    if(isset($_POST['add'])) {

        include("connect.php");

        $name = $_POST['name'];
        $price = $_POST['price'];
        $image = addslashes(file_get_contents($_FILES['image']['tmp_name']));

        $insert = "INSERT INTO e_shop (name, price, image) VALUES ('$name', '$price', '$image')";

        if ($conn->query($insert) === TRUE) {
            echo "<script>alert('Data inserted')</script>";
        }
        else {
            echo "<script>alert('Failed to insert data')</script>";
        }
        
        header("location: main.php");
        $conn->close();
    }
?>